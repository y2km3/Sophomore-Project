-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: localhost    Database: Bank
-- ------------------------------------------------------
-- Server version	5.6.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Account`
--

DROP TABLE IF EXISTS `Account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Account` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(45) NOT NULL,
  `middleName` varchar(45) NOT NULL,
  `lastName` varchar(45) NOT NULL,
  `dateOfBirth` date NOT NULL,
  `street` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `state` varchar(45) NOT NULL,
  `country` varchar(45) NOT NULL,
  `zipCode` varchar(45) NOT NULL,
  `gender` char(1) NOT NULL,
  `contactNumber` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Account`
--

LOCK TABLES `Account` WRITE;
/*!40000 ALTER TABLE `Account` DISABLE KEYS */;
INSERT INTO `Account` VALUES (47,'Yousif','Esho','Kashat','1996-05-16','1073 Adele Ct.','Rochester Hills','Michigan','United States of America','48309','m','248-417-5151','example','pass'),(48,'1','1','1','1996-05-16','11','11','11','11','11','f','11','11','1111'),(49,'yous','kjadsl;j','kdjasl;j','1996-05-16','jdsfla;f','lkjdsa;lj','klsdja;','lkjd;alj','lk;djsfal;j','m','adfsad','adsfda','dsafads'),(50,'Yousif','Esho','Kashat','1996-05-16','1073 Adele Ct.','Rochester Hills','Michigan','United States','48309','m','1484175151','yousif.kashat','abc124'),(51,'111','111','111','1111-11-11','123','123','123','123','123','m','2484175151','123','123'),(52,'123','123','123','1996-12-12','123','123','123','213','123','m','12312312','1233','1233'),(53,'12','12','12','1996-05-16','12','12','12','12','12','m','2484175151','123','123'),(54,'12','12','12','1996-05-16','12','12','12','12','12','m','2484175151','123','123'),(55,'12','12','12','1996-05-16','12','12','12','12','12','m','12','12','12'),(56,'123','123','123','1996-05-16','123','123','123','123','123','m','123','123','123'),(57,'11','11','11','1996-05-16','11','11','11','11','11','m','123','123','123'),(58,'123','123','123','1996-05-16','123','123','123','123','123','m','123','1231','1123'),(59,'121','12','12','1996-05-16','12','12','12','12','12','m','12','12','12'),(60,'12','12','12','1996-05-16','12','12','12','121','12','m','123','123','123'),(61,'11','11','11','1996-05-16','11','11','11','11','11','m','248-417-5151','12','12'),(62,'11','11','11','1996-05-16','1','1','1','1','1','m','2484175151','123','123'),(63,'1','1','1','1996-05-16','1','1','1','11','1','m','2484175151','123','123'),(64,'11','11','11','1996-05-16','11','11','11','11','11','m','123','123','123'),(65,'11','11','11','1996-05-16','11','11','11','11','11','m','1234','123','123'),(66,'11','11','11','1996-05-16','11','11','11','11','11','m','2484175151','123','123'),(67,'11','11','11','1996-05-16','11','11','11','11','11','m','1234','1234','1234'),(68,'123','123','123','1996-05-16','123','123','123','123','123','m','2484175151','12341','1234'),(69,'12','12','12','1996-05-16','12','12','12','12','12','m','123','123','123'),(70,'11','11','11','1996-05-16','11','11','11','11','11','m','123','123','123'),(71,'11','11','1','1996-05-16','1','1','1','1','1','m','12','123','123');
/*!40000 ALTER TABLE `Account` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-17 11:47:07
